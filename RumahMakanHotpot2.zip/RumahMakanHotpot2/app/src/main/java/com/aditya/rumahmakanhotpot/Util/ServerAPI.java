package com.aditya.rumahmakanhotpot.Util;



public class ServerAPI {
   public static final String URL_DATA_FOOD = "http://192.168.1.4/fo/food/view_data.php";
   public static final String URL_DATA = "http://192.168.1.4/fo/order/view_data.php";
   public static final String URL_INSERT_PESAN = "http://192.168.1.4/fo/order/create_data.php";


}
